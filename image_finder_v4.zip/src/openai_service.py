import base64
import mimetypes
import os
from pathlib import Path

from openai import OpenAI


class OpenAIImageService:
    """Handles image descriptions and text embeddings."""

    def __init__(self):
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY is not set.")

        self.client = OpenAI(api_key=api_key)
        self.vision_model = os.getenv("OPENAI_VISION_MODEL", "gpt-4o")
        self.embedding_model = os.getenv(
            "OPENAI_EMBEDDING_MODEL",
            "text-embedding-3-large",
        )

    def describe_image(self, image_path: Path) -> str:
        """Generate a searchable, factual description of an image."""
        mime_type, _ = mimetypes.guess_type(image_path.name)
        mime_type = mime_type or "image/jpeg"

        image_bytes = image_path.read_bytes()
        encoded = base64.b64encode(image_bytes).decode("utf-8")
        data_url = f"data:{mime_type};base64,{encoded}"

        response = self.client.responses.create(
            model=self.vision_model,
            input=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_text",
                            "text": (
                                "Opisz to zdjęcie w języku polskim. "
                                "Utwórz konkretny, rzeczowy opis przydatny do późniejszego "
                                "wyszukiwania semantycznego. Uwzględnij główne obiekty, "
                                "ludzi (bez identyfikowania ich), czynności, miejsce/scenę, "
                                "kolory, istotne szczegóły i relacje między obiektami. "
                                "Nie dodawaj informacji, których nie można wiarygodnie "
                                "wywnioskować z obrazu."
                            ),
                        },
                        {
                            "type": "input_image",
                            "image_url": data_url,
                        },
                    ],
                }
            ],
        )

        description = response.output_text.strip()

        if not description:
            raise RuntimeError("Vision model returned an empty description.")

        return description

    def create_embedding(self, text: str) -> list[float]:
        response = self.client.embeddings.create(
            model=self.embedding_model,
            input=text,
        )
        return response.data[0].embedding
