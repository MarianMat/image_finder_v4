import hashlib
import re
from pathlib import Path
from uuid import uuid4

from src.openai_service import OpenAIImageService


def _safe_filename(filename: str) -> str:
    name = Path(filename).name
    name = re.sub(r"[^a-zA-Z0-9._-]+", "_", name)
    return name or "image"


def process_image(uploaded_file, images_dir: Path, store):
    """Save an uploaded image, generate description, embedding and store metadata."""
    content = uploaded_file.getvalue()

    if not content:
        raise ValueError("Plik jest pusty.")

    extension = Path(uploaded_file.name).suffix.lower()
    if extension not in {".jpg", ".jpeg", ".png", ".webp"}:
        raise ValueError(f"Nieobsługiwany format: {extension}")

    image_id = str(uuid4())
    safe_name = _safe_filename(uploaded_file.name)
    image_path = images_dir / f"{image_id}_{safe_name}"
    image_path.write_bytes(content)

    try:
        ai = OpenAIImageService()
        description = ai.describe_image(image_path)

        store.add_image(
            image_id=image_id,
            image_path=image_path,
            filename=uploaded_file.name,
            description=description,
        )

        return {
            "image_id": image_id,
            "filename": uploaded_file.name,
            "image_path": str(image_path),
            "description": description,
        }

    except Exception:
        # Do not leave an orphaned image if AI/Qdrant processing fails.
        if image_path.exists():
            image_path.unlink()
        raise
