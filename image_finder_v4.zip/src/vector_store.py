from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from qdrant_client import QdrantClient
from qdrant_client.models import Distance, PointStruct, VectorParams

from src.openai_service import OpenAIImageService


class ImageVectorStore:
    """Persistent local Qdrant store for image descriptions and embeddings."""

    VECTOR_SIZE = 3072  # text-embedding-3-large default dimension

    def __init__(self, path: str, collection_name: str):
        self.path = Path(path)
        self.collection_name = collection_name
        self.client = QdrantClient(path=str(self.path))
        self.ai = OpenAIImageService()

        self._ensure_collection()

    def _ensure_collection(self):
        collections = self.client.get_collections().collections
        names = {collection.name for collection in collections}

        if self.collection_name not in names:
            self.client.create_collection(
                collection_name=self.collection_name,
                vectors_config=VectorParams(
                    size=self.VECTOR_SIZE,
                    distance=Distance.COSINE,
                ),
            )

    def add_image(
        self,
        image_id: str,
        image_path: Path,
        filename: str,
        description: str,
    ):
        embedding = self.ai.create_embedding(description)

        payload = {
            "image_id": image_id,
            "filename": filename,
            "image_path": str(image_path),
            "description": description,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        self.client.upsert(
            collection_name=self.collection_name,
            points=[
                PointStruct(
                    id=str(uuid4()),
                    vector=embedding,
                    payload=payload,
                )
            ],
        )

        return payload

    def search(
        self,
        query: str,
        limit: int = 6,
        score_threshold: float | None = None,
    ) -> list[dict]:
        query_embedding = self.ai.create_embedding(query)

        response = self.client.query_points(
            collection_name=self.collection_name,
            query=query_embedding,
            limit=limit,
            score_threshold=score_threshold,
            with_payload=True,
        )

        results = []

        for point in response.points:
            payload = point.payload or {}
            image_path = Path(payload.get("image_path", ""))

            if not image_path.exists():
                continue

            results.append(
                {
                    "score": float(point.score),
                    "image_id": payload.get("image_id"),
                    "filename": payload.get("filename"),
                    "image_path": str(image_path),
                    "description": payload.get("description", ""),
                    "created_at": payload.get("created_at"),
                }
            )

        return results
